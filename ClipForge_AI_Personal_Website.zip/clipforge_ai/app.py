import os, json, tempfile, subprocess, shutil, re
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory, render_template
from werkzeug.utils import secure_filename
from openai import OpenAI

ROOT = Path(__file__).parent.resolve()
UPLOADS = ROOT / "uploads"
OUTPUTS = ROOT / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024  # 2 GB demo limit
client = OpenAI() if os.getenv("OPENAI_API_KEY") else None
ALLOWED = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout or "Command failed")[-1800:])
    return p.stdout

def download_authorized_youtube(url, dest):
    # yt-dlp only works where access is permitted. Use only content you own or have permission to edit.
    run(["yt-dlp", "--no-playlist", "-f", "bv*+ba/b", "--merge-output-format", "mp4", "-o", str(dest), url])
    if not dest.exists():
        candidates = list(dest.parent.glob(dest.stem + ".*"))
        if candidates:
            candidates[0].replace(dest)
    if not dest.exists():
        raise RuntimeError("Video download did not produce an MP4 file.")

def get_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(out.strip())

def transcribe(path):
    if not client:
        raise RuntimeError("Missing OPENAI_API_KEY. Add it to your .env file and restart.")
    with open(path, "rb") as f:
        result = client.audio.transcriptions.create(
            model="whisper-1", file=f, response_format="verbose_json", timestamp_granularities=["segment"]
        )
    data = result.model_dump() if hasattr(result, "model_dump") else dict(result)
    segments = data.get("segments", [])
    if not segments:
        raise RuntimeError("No timestamped transcript returned. Try a clearer video/audio track.")
    return segments

def choose_clips(segments, duration, count=12, clip_len=30):
    if not client:
        raise RuntimeError("Missing OPENAI_API_KEY.")
    transcript = "\n".join(
        f'[{float(s.get("start",0)):.1f}-{float(s.get("end",0)):.1f}] {s.get("text","")}'
        for s in segments
    )
    prompt = f"""
You are an expert short-form podcast clip editor. Select up to {count} distinct, compelling clips from this timestamped transcript.
Video duration: {duration:.1f} seconds. Target clip duration: 20-{clip_len} seconds.
Return ONLY valid JSON: {{"clips":[{{"start":0.0,"end":25.0,"hook":"short strong opening hook","caption":"natural social caption","title":"short label"}}]}}.
Rules: use only timestamps supported by the transcript; start < end; each clip should be 20-{clip_len} seconds where possible; select self-contained moments with a clear payoff, tension, surprise, insight, or strong opinion; avoid overlapping clips when possible; hooks must accurately represent what is said, no fabricated claims; caption should be concise; maximum {count} clips.
Transcript:
{transcript[:24000]}
"""
    response = client.chat.completions.create(
        model=os.getenv("OPENAI_TEXT_MODEL", "gpt-4o-mini"),
        messages=[{"role":"system","content":"You select accurate, high-retention short video moments."},
                  {"role":"user","content":prompt}],
        response_format={"type":"json_object"},
        temperature=0.4,
    )
    obj = json.loads(response.choices[0].message.content)
    clips = []
    for i, c in enumerate(obj.get("clips", [])[:count], 1):
        try:
            start = max(0, float(c["start"]))
            end = min(duration, float(c["end"]))
            if end - start < 5 or start >= end:
                continue
            clips.append({"id": i, "start": start, "end": end,
                          "hook": str(c.get("hook",""))[:140],
                          "caption": str(c.get("caption",""))[:500],
                          "title": str(c.get("title", f"Clip {i}"))[:100]})
        except (KeyError, TypeError, ValueError):
            continue
    return clips

def make_clip(source, clip, index):
    name = f"clip_{index:02d}.mp4"
    out = OUTPUTS / name
    start, end = clip["start"], clip["end"]
    # Burn a simple hook overlay and preserve audio. For polished animated captions, add a dedicated subtitle workflow.
    hook = re.sub(r"[^A-Za-z0-9 .,!?'-]", "", clip.get("hook",""))[:75]
    vf = "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2"
    if hook:
        safe = hook.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        vf += f",drawtext=text='{safe}':fontcolor=white:fontsize=48:borderw=3:bordercolor=black:x=(w-text_w)/2:y=120:box=1:boxcolor=black@0.45:boxborderw=18"
    run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(end-start),
         "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "24",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(out)])
    clip["file"] = name
    return clip

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/process")
def process():
    source = None
    try:
        url = (request.form.get("youtube_url") or "").strip()
        if "video" in request.files and request.files["video"].filename:
            f = request.files["video"]
            ext = Path(secure_filename(f.filename)).suffix.lower()
            if ext not in ALLOWED:
                return jsonify(error="Unsupported video format. Use MP4, MOV, MKV, WEBM or M4V."), 400
            source = UPLOADS / (next(tempfile._get_candidate_names()) + ext)
            f.save(source)
        elif url:
            if not re.match(r"^https?://(www\.)?(youtube\.com|youtu\.be)/", url):
                return jsonify(error="Please enter a valid YouTube URL."), 400
            source = UPLOADS / (next(tempfile._get_candidate_names()) + ".mp4")
            download_authorized_youtube(url, source)
        else:
            return jsonify(error="Upload a video or paste a YouTube URL."), 400

        duration = get_duration(source)
        segments = transcribe(source)
        clips = choose_clips(segments, duration, count=12, clip_len=30)
        rendered = []
        for i, clip in enumerate(clips, 1):
            rendered.append(make_clip(source, clip, i))
        return jsonify(ok=True, duration=duration, clips=rendered,
                       note="Processing time depends on video length, internet speed, and API/CPU capacity.")
    except Exception as e:
        return jsonify(error=str(e)), 500
    finally:
        # Keep output clips for download; remove temporary source after processing.
        if source and source.exists():
            try: source.unlink()
            except OSError: pass

@app.get("/outputs/<path:filename>")
def download(filename):
    return send_from_directory(OUTPUTS, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
