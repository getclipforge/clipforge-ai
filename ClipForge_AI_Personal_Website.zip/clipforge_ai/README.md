# ClipForge AI — Personal clipping website

A personal web app starter that accepts a video upload or a YouTube URL, transcribes it, asks an AI model to select up to 12 compelling moments, creates vertical MP4 clips, and supplies editable hook/caption fields.

## Important reality check
- This is a starter project, not a hosted service. It needs to run on a computer/server with Python and FFmpeg.
- 10–20 seconds for a full long video is **not guaranteed**. Uploading, transcription, AI selection, and rendering usually take longer and depend on video length, network, API limits, and CPU/GPU resources.
- YouTube links may fail because of access restrictions, age/region restrictions, or platform changes. Use only videos you own or have permission to edit, and comply with YouTube's terms.
- Captions in this version are editable social captions, not word-by-word burned subtitles. Hooks are burned into the top of the video. A production version should add timed subtitles, job queue, cloud storage, and authentication.

## Requirements
- Python 3.10+
- FFmpeg and ffprobe installed and available on PATH
- An OpenAI API key with API billing enabled

## Run locally
1. Unzip the project.
2. Open a terminal in the `clipforge_ai` folder.
3. Create a virtual environment:
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and add your API key.
6. Load environment variables before starting:
   - macOS/Linux: `set -a && source .env && set +a && python app.py`
   - Windows PowerShell: `$env:OPENAI_API_KEY="your_key"; python app.py`
     (Set `OPENAI_TEXT_MODEL` similarly if desired.)
7. Open `http://127.0.0.1:5000` in your browser.

## Notes
- The API key must stay on the server and must never be placed in frontend JavaScript.
- For public deployment, add authentication, request limits, secure storage, HTTPS, and cleanup of old outputs. Do not expose this development server directly to the internet.
- The current implementation processes one request at a time and keeps rendered outputs in `outputs/`.
